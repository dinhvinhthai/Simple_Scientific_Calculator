# Contribution highly appreciated :-)

### You can start contributing via
- Giving a star to the repo :-)
- Finding and reporting bugs
- Asking for new nice features
- Implementing new features by your own - pls check the list of issues

#### General guidelines 
- mXparser is developed in java, then ported to c-sharp, but you can develop in java or in c-sharp. I will be happy to port your code from java to c-sharp or the other way from c-sharp to java
- Development is done in Eclipse (java) and VS Community 2017 (.net)
