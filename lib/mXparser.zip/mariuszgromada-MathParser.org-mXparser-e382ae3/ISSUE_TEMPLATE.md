### Issue title:
- Short and meaningfull

### Issue content:

#### If bug/question:
- MathParser.org-mXparser verssion: v.X.Y.Z
- Framework: java, .net, .net core, .net standard, Xamarin, Android, iOS ... + framework verssion
- Problem description
- Code example

#### If new feature
- Feature description
- Use case description
